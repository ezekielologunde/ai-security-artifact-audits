"""Conservative claim checks. No model imports, deserialization, or universal safety score."""
import ast, copy, hashlib, json, re

CONTRADICTED='contradicted'
CONSISTENT='consistent-with-observed-evidence'
UNKNOWN='unverifiable'

def bind_loader_call(snapshot):
    """Bind a documented expression syntactically; never execute or resolve imports."""
    selected=snapshot.get('loading_path',{})
    line=selected.get('readme_call_line')
    result={'binding':'unverifiable','reason':'An exact README call line is required.'}
    if type(line) is not int or line<1:return result
    lines=snapshot.get('readme','').splitlines()
    fence=None; block=[]; start=0
    for number,text in enumerate(lines,1):
        marker=re.match(r'^\s{0,3}(`{3,}|~{3,})(.*)$',text)
        if marker and fence is None:
            token,label=marker.groups()
            fence=(token[0],len(token),label.strip().lower() in ('python','python3','py'))
            block=[];start=number+1
        elif marker and fence and marker.group(1)[0]==fence[0] and len(marker.group(1))>=fence[1] and not marker.group(2).strip():
            if fence[2] and start<=line<number:
                result['reason']='Selected expression is outside the supported direct literal-call grammar.'
                try:tree=ast.parse('\n'.join(block))
                except SyntaxError:return result
                for node in ast.walk(tree):
                    if not isinstance(node,ast.Call) or start+node.lineno-1!=line:continue
                    func=node.func
                    if not (isinstance(func,ast.Attribute) and func.attr=='from_pretrained'
                            and isinstance(func.value,ast.Name) and func.value.id==selected.get('auto_class')):continue
                    if not node.args or any(isinstance(a,ast.Starred) for a in node.args):continue
                    target=node.args[0]
                    if not isinstance(target,ast.Constant) or not isinstance(target.value,str):continue
                    if normalize_model_id(target.value)!=normalize_model_id(snapshot['model_id']):continue
                    if any(k.arg is None for k in node.keywords):continue
                    flags=[k.value for k in node.keywords if k.arg=='trust_remote_code']
                    if len(flags)!=1 or not isinstance(flags[0],ast.Constant) or type(flags[0].value) is not bool:continue
                    flag=flags[0].value
                    if 'trust_remote_code' in selected and selected['trust_remote_code'] is not flag:
                        result['reason']='Selected trust flag conflicts with the bound README expression.'
                        return result
                    return {'binding':'syntactic-match','trust_remote_code':flag,
                            'source':{'file':'README.md','line':line,'revision':snapshot['revision']},
                            'expression':ast.get_source_segment('\n'.join(block),node),
                            'reason':'Literal model ID and selected class match; imports and runtime behavior remain unverified.'}
                return result
            fence=None;block=[]
        elif fence:block.append(text)
    return result

def extract_loader_context(readme,revision):
    """Lexical observations only: mentions do not select a loading path."""
    patterns={'transformers':r'\btransformers\b',
              'mlx':r'\bmlx(?:[-_]lm)?\b',
              'llama.cpp':r'\bllama\.cpp\b'}
    observations=[]; fence=None
    for number,line in enumerate(readme.splitlines(),1):
        text=line.lstrip()
        marker=re.match(r'(`{3,}|~{3,})',text)
        if marker:
            token=marker.group(1)
            if fence is None:fence=(token[0],len(token))
            elif token[0]==fence[0] and len(token)>=fence[1] and not text[len(token):].strip():fence=None
            continue
        loaders=[name for name,pattern in patterns.items() if re.search(pattern,line,re.I)]
        condition=bool(re.search(r'\b(?:requires?|at least|recent|version)\b|>=',line,re.I))
        qualification=condition and bool(loaders or re.search(r'\b(?:recent|version)\b',line,re.I))
        if loaders or qualification:
            observations.append({'source':{'file':'README.md','line':number,'revision':revision},
                                 'quote':line,'loader_mentions':loaders,
                                 'qualification_candidate':qualification,
                                 'in_fenced_code':fence is not None,
                                 'in_blockquote':text.startswith('>')})
    return {'method':'lexical-mentions-v1','scope_binding':'unverified',
            'nearby_window_lines':4,'observations':observations,
            'limitations':['Mentions do not establish the selected loader or runtime support.',
                           'Conditions are lexical candidates, not a complete dependency or version parser.']}

def normalize_model_id(value):
    value=str(value).strip().strip('`\"\'').rstrip('/.')
    value=re.sub(r'^https?://huggingface\.co/', '', value)
    return value  # Hub IDs are case-sensitive; do not collapse arbitrary aliases.

def extract_claims(readme):
    claims=[]; in_code=False
    for number,line in enumerate(readme.splitlines(),1):
        text=line.strip()
        if text.startswith('```'): in_code=not in_code; continue
        if in_code or text.startswith('>'): continue
        kind=None; value=None; scope='repository'
        lower=text.lower()
        if re.search(r'\b(only|exclusively)\s+(?:in\s+)?safetensors\b|\bno\s+pickle(?:[- ]based)?\s+(?:files|weights|artifacts)\b|\bpickle[- ]free\b',lower):
            # "not only" and quoted recommendations are not exclusivity assertions.
            if 'not only' in lower or re.search(r'\b(should|recommend|example)\b',lower): continue
            kind='serialization'; value='no-pickle'
            if re.search(r'\b(selected|recommended|this)\s+(?:loading\s+)?path\b',lower):scope='loading-path'
        elif re.search(r'\bno\s+custom\s+(?:python\s+)?code\b|\bdoes not require\s+custom\s+(?:python\s+)?code\b',lower):
            if re.search(r'\b(should|recommend|example)\b',lower):continue
            kind='custom-code';value='no-custom-code';scope='loading-path'
        else:
            match=re.search(r'\b(?:adapter\s+(?:requires|loads|uses)(?:\s+base\s+model)?|adapter\s+base(?:\s+model)?\s*:)\s+[`\"]?((?:https?://huggingface\.co/)?[\w.-]+/[\w.-]+)',text,re.I)
            if match:kind='adapter-base';value=normalize_model_id(match.group(1));scope='adapter-load-dependency'
        if kind:
            claims.append({'claim_type':kind,'claim_value':value,'claim_quote':line,'claim_scope':scope,
                           'source':{'file':'README.md','line':number}})
    return claims

def bind_report(snapshot,report):
    if not report:return 'absent'
    target=report.get('target',{})
    if target.get('model_id')!=snapshot['model_id'] or target.get('revision')!=snapshot['revision']:return 'mismatched-target-or-revision'
    expected={x['path']:x.get('sha256') for x in snapshot.get('artifacts',[]) if x.get('sha256')}
    scanned=report.get('artifact_sha256',{})
    if not scanned:return 'unknown-artifact-identity'
    if any(expected.get(path)!=digest for path,digest in scanned.items()):return 'mismatched-artifact-hash'
    if any(path not in scanned for path in report.get('verified_formats',{})):return 'unbound-format-evidence'
    return 'matched'

def analyze(snapshot,report=None,mode='overlay'):
    snapshot=copy.deepcopy(snapshot)
    loader_context=extract_loader_context(snapshot.get('readme',''),snapshot['revision'])
    binding=bind_report(snapshot,report)
    allow_stale=mode=='overlay_without_revision_binding'
    scope_enabled=mode!='overlay_without_scope'
    docs_only=mode=='documentation_only'
    findings=[]
    artifacts=[] if docs_only else snapshot.get('artifacts',[])
    weight_artifacts=[a for a in artifacts if a.get('format') in ('pickle','safetensors') or a['path'].lower().endswith(('.bin','.pt','.pth','.pkl','.pickle','.safetensors'))]
    formats={a['path']:a.get('format','unknown') for a in weight_artifacts}
    if mode=='filename_rule':
        formats={a['path']:('pickle' if a['path'].lower().endswith(('.bin','.pt','.pth','.pkl','.pickle')) else a.get('format','unknown')) for a in weight_artifacts}
    if report and (binding=='matched' or allow_stale) and not docs_only:
        formats.update({p:v for p,v in report.get('verified_formats',{}).items() if p in {a['path'] for a in artifacts}})
    selected=snapshot.get('loading_path',{}).get('artifacts')
    config={} if docs_only else snapshot.get('config',{})
    adapter={} if docs_only else snapshot.get('adapter_config',{})
    trust=bool(re.search(r'trust_remote_code\s*=\s*True',snapshot.get('readme','')))
    loader_binding=bind_loader_call(snapshot) if mode=='overlay_bound_loader' else None
    scoped_trust=(loader_binding.get('trust_remote_code') is True) if loader_binding is not None else trust
    selected_trust=snapshot.get('loading_path',{}).get('trust_remote_code')
    if 'trust_remote_code' in snapshot.get('loading_path',{}) and not isinstance(selected_trust,bool):
        raise ValueError('loading_path.trust_remote_code must be a JSON boolean')
    local_py={a['path'][:-3].replace('/','.') for a in artifacts if a['path'].endswith('.py')}
    auto=config.get('auto_map',{})
    references=[]
    for entry in auto.values():
        references.extend(entry if isinstance(entry,list) else [entry])
    # External auto_map modules and unselected loader paths remain indeterminate.
    selected_class=snapshot.get('loading_path',{}).get('auto_class')
    selected_refs=auto.get(selected_class) if selected_class else None
    if isinstance(selected_refs,str):selected_refs=[selected_refs]
    code_used=bool(scoped_trust and selected_trust is not False and selected_refs and any(isinstance(r,str) and '--' not in r and r.rsplit('.',1)[0] in local_py for r in selected_refs))
    for claim in extract_claims(snapshot.get('readme','')):
        claim['source']['revision']=snapshot['revision']
        claim['nearby_loader_context_lines']=[o['source']['line'] for o in loader_context['observations']
                                               if abs(o['source']['line']-claim['source']['line'])<=4]
        status=UNKNOWN; evidence=[]; reason='Required evidence is unavailable or outside the implemented grammar.'
        if claim['claim_type']=='serialization':
            paths=list(formats)
            if claim['claim_scope']=='loading-path' and scope_enabled:
                paths=selected or []
            inspected=[{'path':p,'format':formats.get(p,'unknown')} for p in paths]
            evidence=inspected
            if any(x['format']=='pickle' for x in inspected):status=CONTRADICTED;reason='Confirmed pickle-format evidence conflicts with the stated scope.'
            elif inspected and all(x['format']=='safetensors' for x in inspected):status=CONSISTENT;reason='All inspected artifacts in the stated scope have Safetensors structure.'
        elif claim['claim_type']=='adapter-base':
            observed=adapter.get('base_model_name_or_path')
            if observed:
                evidence=[{'file':'adapter_config.json','base_model_name_or_path':observed}]
                if '/' not in str(observed) or str(observed).startswith(('/', '.', 'C:', 'D:')):reason='A local path cannot be resolved to a Hub model identity.'
                else:
                    status=CONSISTENT if normalize_model_id(observed)==claim['claim_value'] else CONTRADICTED
                    reason='Compared declarations of the same adapter loading dependency; this does not authenticate training lineage.'
        elif claim['claim_type']=='custom-code':
            evidence=[{'documented_trust_remote_code':trust,'selected_auto_class':selected_class,'selected_auto_map':selected_refs,
                       'selected_trust_remote_code':selected_trust}]
            if loader_binding is not None:evidence[0]['bound_loader_call']=loader_binding
            if code_used:status=CONTRADICTED;reason='The documented selected loader enables a referenced custom module present at this revision.'
            elif selected_class and selected_class not in auto and config and not docs_only:
                status=CONSISTENT;reason='No custom mapping exists for the selected loader in the inspected configuration.'
        findings.append({**claim,'consistency':status,'reason':reason,'evidence':evidence})
    load_paths=list(formats) if not scope_enabled or mode=='filename_rule' else (selected or [])
    confirmed_pickle=any(formats.get(p)=='pickle' for p in load_paths)
    exposure='observed-loading-exposure' if confirmed_pickle or code_used else 'indeterminate'
    if not confirmed_pickle and not code_used and load_paths and all(formats.get(p)=='safetensors' for p in load_paths) and selected_class and selected_class not in auto and config:
        exposure='no-exposure-observed-within-inspected-scope'
    declared=snapshot.get('card_data',{}).get('base_model',[])
    if isinstance(declared,str):declared=[declared]
    declared=[normalize_model_id(x) for x in declared if isinstance(x,str)] if isinstance(declared,list) else []
    observed=adapter.get('base_model_name_or_path')
    provenance={'card_bases':declared,'adapter_load_dependency':observed,'consistency':UNKNOWN,'candidate_disagreement':False,
                'reason':'A comparable card declaration or adapter dependency is absent.'}
    if observed and declared:
        if str(observed).startswith(('/', '.', 'C:', 'D:')) or '/' not in str(observed):
            provenance['reason']='The adapter records an unresolved local path.'
        elif normalize_model_id(observed) in declared:
            provenance.update(consistency=CONSISTENT,reason='The adapter loading dependency appears among the declared card bases; training provenance remains unauthenticated.')
        else:
            provenance.update(candidate_disagreement=True,reason='Different published IDs require review of relationship semantics, aliases and intermediate transformations; false lineage is not established.')
    return {'schema_version':'0.1','target':{'model_id':snapshot['model_id'],'revision':snapshot['revision']},
            'upstream_report':copy.deepcopy(report),
            'overlay':{'mode':mode,'scanner_binding':binding,'claim_assessments':findings,'provenance_comparison':provenance,'loading_exposure':exposure,
                       'loader_context':loader_context,
                       'limitations':['Only the implemented explicit-claim grammar is assessed.','Agreement does not authenticate provenance or establish safety.','No model code or weight deserialization was executed.']+
                           (['Strict loader binding is syntactic only; imports, claim-to-call association and runtime behavior are unverified.'] if mode=='overlay_bound_loader' else [])}}
