import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'data/lightfoot-qualification-20261121'
WORK = ROOT / 'work/lightfoot-snapshot-repair-20261123'
OUT = ROOT / 'results/lightfoot-snapshot-repair-20261123'
WORK.mkdir(exist_ok=False)
OUT.mkdir(exist_ok=False)
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before = {p.relative_to(SOURCE).as_posix():sha(p) for p in SOURCE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
derived = WORK / 'derived-source'
assert derived.resolve().is_relative_to(ROOT.resolve())
shutil.copytree(SOURCE, derived, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
target = derived / 'lightfoot/store/sqlite_store.py'
old = target.read_text(encoding='utf-8')
old_block = '''        snapshot = None
        if not self._vec_dir:
            snapshot = {}
            for n, i in self._indexes.items():
                ids, mat = i.all()
                attrs = [{a: i._attrs[a][i._row[k]] for a in i.attr_names} for k in ids]
                snapshot[n] = (ids, mat, attrs)'''
new_block = '''        # Authored comparator: use the existing native entry snapshot for every backend.
        snapshot = {}
        for n, i in self._indexes.items():
            ids, mat = i.all()
            attrs = [{a: i._attrs[a][i._row[k]] for a in i.attr_names} for k in ids]
            snapshot[n] = (ids, mat, attrs)'''
assert old.count(old_block) == 1
new = old.replace(old_block,new_block)
target.write_text(new,encoding='utf-8')
(OUT / 'snapshot-at-entry.patch').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='upstream/lightfoot/store/sqlite_store.py',tofile='derived/lightfoot/store/sqlite_store.py')),encoding='utf-8')
original_harness = ROOT / 'run_lightfoot_rollback_controls.py'
h = original_harness.read_text(encoding='utf-8').replace('import platform','import platform\nimport os')
h = h.replace("SOURCE=ROOT/'data/lightfoot-qualification-20261121'", "SOURCE=Path(os.environ['LIGHTFOOT_SOURCE'])")
h = h.replace("PROTOCOL=ROOT/'LIGHTFOOT_ROLLBACK_PROTOCOL_20261121.json'", "PROTOCOL=ROOT/'LIGHTFOOT_SNAPSHOT_REPAIR_PROTOCOL_20261123.json'")
h = h.replace("WORK=ROOT/'work/lightfoot-rollback-controls-v1'", "WORK=ROOT/'work'/('lightfoot-repair-controls-'+os.environ['LIGHTFOOT_VARIANT'])")
h = h.replace("out=ROOT/'results/lightfoot_rollback_controls_20261121.json'", "out=ROOT/'results'/('lightfoot_snapshot_repair_'+os.environ['LIGHTFOOT_VARIANT']+'_20261123.json')")
harness = ROOT / 'run_lightfoot_snapshot_repair_conditions_20261123.py'
assert not harness.exists()
harness.write_text(h,encoding='utf-8')
calls = []
for variant, folder in [('original',SOURCE),('repaired',derived)]:
    env = dict(os.environ, LIGHTFOOT_SOURCE=str(folder), LIGHTFOOT_VARIANT=variant)
    p = subprocess.run([sys.executable,str(harness)],env=env,capture_output=True,encoding='utf-8',timeout=90)
    (OUT / (variant+'-stdout.txt')).write_text(p.stdout,encoding='utf-8')
    (OUT / (variant+'-stderr.txt')).write_text(p.stderr,encoding='utf-8')
    calls.append({'variant':variant,'source_path':str(folder),'exit_code':p.returncode})
    assert p.returncode == 0, p.stderr
original = json.loads((ROOT / 'results/lightfoot_snapshot_repair_original_20261123.json').read_text())
repaired = json.loads((ROOT / 'results/lightfoot_snapshot_repair_repaired_20261123.json').read_text())
def summary(data):
    return [{'change':r['change'],'condition':r['condition'],'rows_preserved':r['rows_preserved'],
             'vectors_preserved':r['vectors_preserved'],'search_preserved':r['search_preserved'],
             'reopen_equals_entry': r['after_reopen'] == r['before_abort'] if r['after_reopen'] is not None else None}
            for r in data['conditions']]
old_rows,new_rows=summary(original),summary(repaired)
checks={'six_conditions_each':len(old_rows)==len(new_rows)==6,
        'original_two_known_vector_mismatches':sum(not r['vectors_preserved'] for r in old_rows)==2,
        'repair_preserves_all_live_states':all(r['rows_preserved'] and r['vectors_preserved'] and r['search_preserved'] for r in new_rows),
        'repair_preserves_all_file_reopen_states':all(r['reopen_equals_entry'] is True for r in new_rows if r['condition']!='memory'),
        'acquired_source_unchanged':before=={p.relative_to(SOURCE).as_posix():sha(p) for p in SOURCE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}}
result={'checks':checks,'all_pass':all(checks.values()),'calls':calls,'original':old_rows,'repaired':new_rows,
        'original_harness_sha256':sha(original_harness),'derived_harness_sha256':sha(harness),
        'upstream_store_sha256':sha(SOURCE/'lightfoot/store/sqlite_store.py'),'derived_store_sha256':sha(target),
        'protocol_sha256':sha(ROOT/'LIGHTFOOT_SNAPSHOT_REPAIR_PROTOCOL_20261123.json'),
        'new_model_calls':0,'scope':'Standard snapshot-at-entry repair on tiny native storage fixtures only; not novel algorithm, scale benchmark, crash atomicity or RAG-wide erasure.'}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
assert result['all_pass']
