# P23 transaction-entry snapshot repair

An authored repair of the confirmed Lightfoot storage rollback mismatch passes the same six native storage controls, including close/reopen. It applies a standard snapshot-at-entry technique already present in the upstream in-memory backend to file-backed transactions and ensures restored empty indexes are persisted. This is an implementation repair, not a novel transaction algorithm or RAG-wide erasure mechanism.

## Design and intervention

Original source remains pinned at `fbba969e73eaeaf45e1e8a8ad33a96cfeadbb66d` and unchanged. A separate copied package changes only `lightfoot/store/sqlite_store.py`; a unified diff is retained. Both variants run the original six-condition rollback harness with only source/work/output/protocol paths adapted. The final comparison uses the same existing Python3.12.14/NumPy2.2.6/SciPy1.15.3 qualification runtime, synthetic four-dimensional vectors, two prior committed changes and three storage conditions.

The oracle requires exact transaction-entry SQL rows, vectors and public search results after a later abort, plus absence of temporary data. File-backed conditions additionally compare close/reopen state. The six conditions are delete/insert crossed with deferred-file, explicitly flushed-file and memory modes. Repeated versions and checks are not independent incidents.

## Results

| Variant | Live rows/vectors/search preserved | File close/reopen matches entry |
|---|---:|---:|
| Pinned original | 4/6 | 2/4 |
| Entry-snapshot-only first repair | 6/6 | 3/4 |
| Entry snapshot plus dirty restored indexes | 6/6 | 4/4 |

The original two failures are the known deferred-file delete/insert controls. The first repair exposed an empty-state persistence boundary: reinitializing an empty vector index leaves it clean, so close skips saving it and the older vector returns on reopen. The second repair marks restored indexes dirty, including empty ones. All successful controls remain preserved in the final comparison.

The final native run executes six original and six repaired variant-condition cases, all in fresh stores. Both child commands exit0; the combined preservation checks pass. A separate verifier reads all eight closed file-backed SQLite/NPZ fixtures without modifying them and confirms the recorded reopen states, plus the repaired entry-state matches. Its23 checks are verification assertions, not23 scientific trials. Original and copied source inventories differ only in the declared storage file.

## Corrections and preservation

The first launch selected a project environment lacking SciPy and stopped at import before any case; its driver/work/logs remain. The correct runtime was recovered from the prior successful replay receipt. The completed entry-only repair and its failing reopen assertion remain in the r2 outputs. A post-result amendment declared the dirty-empty-state addition before the r3 execution; the final repair is not represented as the original preregistered intervention. The independent verifier initially assumed JSON key encoding; native fixture keys are plain one-component strings. That verifier correction is retained and required no experiment rerun.

## Limits and publication status

The repair snapshots complete vectors/attributes at transaction entry, with memory/time costs not measured at scale. It does not establish concurrent-observer isolation, power-loss/multi-file atomicity, explicit flush inside an aborted transaction, arbitrary nested exception semantics, process-crash recovery or production readiness.

The earlier three native query fixtures and16 post-deletion observations remain unchanged: they did not reveal retired text or final-ranked retired IDs. This new experiment does not rerun that pipeline or show a disclosure fix. There are no learned embeddings, model calls, generated-answer tests, physical-erasure or uncontrolled-copy guarantees. The original ecosystem-wide revocation question remains broader.

The existing public three-page report/reproduction package is unchanged. This repair, its partial failure and final results are local and have not yet been added to that publication. No external submission or upstream contact occurred; reviewer availability is not a preprint gate.

Evidence: `LIGHTFOOT_SNAPSHOT_REPAIR_PROTOCOL_20261123.json`, runtime and empty-state amendments, r2/r3 result directories, and `results/lightfoot-snapshot-repair-20261123-r3/{RESULTS,VERIFICATION}.json` plus `snapshot-at-entry.patch`. The source MIT licence remains applicable to the derivative; authored report/code use CC BY4.0/MIT.
