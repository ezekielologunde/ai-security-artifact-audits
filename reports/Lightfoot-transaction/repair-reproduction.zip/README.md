# Lightfoot storage repair reproduction

Run with Python3.12 and the packages in requirements.txt. A local clean extraction was tested with the existing qualification runtime; no fresh operating system or independent researcher is implied.

    python -m pip install -r requirements.txt
    python REPLAY.py

REPLAY verifies every packaged input, creates fresh work folders, runs the paired original/final-repair six-condition harness, independently reads eight closed SQLite/vector file conditions and compares normalized results with EXPECTED.json. It refuses reuse of existing execution folders. No weights, inference models, hosted services or credentials are needed. It does not execute the historical drivers or replay captured shell commands.

The prior entry-only repair failed the deferred-delete reopen control. Its completed native receipts and driver remain as disclosed intermediate evidence; this clean replay executes only the original and final repaired variants. The earlier missing-SciPy launch stopped before cases. Verifier key-format correction is also retained. Do not count stages or verification assertions as independent incidents.

Original upstream MIT source is under data/lightfoot-qualification-20261121 with its licence. Only a fresh derived copy is patched at execution; the code extends an existing snapshot technique and marks restored empty indexes dirty. The included patch and full recorded results are archival references. Authored code is MIT and authored report text CC BY4.0; upstream terms remain separate.

Scope: finite synthetic native storage rollback and close/reopen controls. No crash/power-loss atomicity, explicit in-transaction flush, concurrency, scale benchmark, query/answer disclosure fix, RAG-wide erasure or novel transaction algorithm is claimed. Published earlier report/package remains separate and unchanged by creating this archive.
