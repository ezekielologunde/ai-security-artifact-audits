import hashlib
import json
from pathlib import Path
import sqlite3
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results/lightfoot-snapshot-repair-20261123-r3'
r = json.loads((OUT / 'RESULTS.json').read_text())
source = ROOT / 'data/lightfoot-qualification-20261121'
derived = ROOT / 'work/lightfoot-snapshot-repair-20261123-r3/derived-source'
files = [p for p in source.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
changed = [p.relative_to(source).as_posix() for p in files if p.read_bytes() != (derived / p.relative_to(source)).read_bytes()]
checks = {'final_all_checks_pass':r['all_pass'], 'only_store_source_changed':changed == ['lightfoot/store/sqlite_store.py']}
observations = []
for variant in ['original_r3','repaired_r3']:
    saved = json.loads((ROOT / f'results/lightfoot_snapshot_repair_{variant}_20261123.json').read_text())
    for row in saved['conditions']:
        if row['condition'] == 'memory': continue
        db = ROOT / f"work/lightfoot-repair-controls-{variant}/{row['change']}-{row['condition']}.db"
        vectors = Path(str(db) + '.vec') / 'chunks.npz'
        before = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [db,vectors]}
        assert not Path(str(db)+'-wal').exists()
        with sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True) as connection:
            connection.row_factory=sqlite3.Row
            rows = sorted([dict(x) for x in connection.execute('SELECT * FROM chunks')],key=lambda x:x['chunk_id'])
        # Only locally generated inert fixtures, never downloaded NPZ/checkpoint data.
        with np.load(vectors,allow_pickle=True) as data:
            values = {str(k):v.tolist() for k,v in zip(data['ids'],data['matrix'])}
        after = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [db,vectors]}
        ident = variant+'_'+row['change']+'_'+row['condition']
        checks[ident+'_matches_recorded_reopen'] = rows==row['after_reopen']['rows'] and values==row['after_reopen']['vectors']
        checks[ident+'_read_preserved_files'] = before==after
        if variant=='repaired_r3': checks[ident+'_matches_transaction_entry'] = rows==row['before_abort']['rows'] and values==row['before_abort']['vectors']
        observations.append({'id':ident,'rows':rows,'vectors':values,'input_hashes':before})
partial=json.loads((ROOT / 'results/lightfoot-snapshot-repair-20261123-r2/RESULTS.json').read_text())
checks['entry_only_failed_reopen_result_preserved'] = partial['checks']['repair_preserves_all_live_states'] and not partial['checks']['repair_preserves_all_file_reopen_states']
result={'checks':checks,'all_pass':all(checks.values()),'changed_source_files':changed,'physical_observations':observations,
        'scope':'Independent closed SQLite/NPZ readback on eight file controls; memory controls remain native recorded observations. No new trial, model, crash or full pipeline claim.'}
(OUT / 'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_pass':result['all_pass'],'checks':len(checks),'changed_source_files':changed,'physical_file_conditions':len(observations)},indent=2))
assert result['all_pass']
