import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
def verified():
    return all((ROOT/name).is_file() and sha(ROOT/name)==item['sha256'] for name,item in manifest.items())
assert verified(),'Packaged input mismatch'
(ROOT/'work').mkdir(exist_ok=True)
calls=[]
for name in ['run_lightfoot_snapshot_repair_20261123.py','verify_lightfoot_snapshot_repair_20261123.py']:
    p=subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,capture_output=True,encoding='utf-8',timeout=90)
    calls.append({'script':name,'exit_code':p.returncode})
    (ROOT/'work'/(name+'.stdout.txt')).write_text(p.stdout,encoding='utf-8')
    (ROOT/'work'/(name+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
    assert p.returncode==0,p.stderr
result=json.loads((ROOT/'results/lightfoot-snapshot-repair-20261123-r3/RESULTS.json').read_text())
expected=json.loads((ROOT/'EXPECTED.json').read_text())
match={key:result[key]==expected[key] for key in ['original','repaired']}
receipt={'commands':calls,'normalized_variant_matches':match,'all_packaged_inputs_unchanged':verified(),
         'scope':'Clean extraction using supplied runtime, not independent OS/human validation or new model evidence.'}
(ROOT/'work/CLEAN_REPLAY.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
assert all(match.values()) and receipt['all_packaged_inputs_unchanged']
