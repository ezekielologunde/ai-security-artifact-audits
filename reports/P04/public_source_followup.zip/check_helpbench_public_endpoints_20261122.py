"""MIT. Two zero-endpoint checks and matched nonzero controls on public native scorer."""
from pathlib import Path
import hashlib, importlib.util, json
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'data/helpbench-public-20261122'
receipt=json.loads((BASE/'ACQUISITION_AND_COMPARISON.json').read_text())
source=BASE/'source/scripts/scoring.py'
entry=next(x for x in receipt['files'] if x['path']=='scripts/scoring.py')
assert hashlib.sha256(source.read_bytes()).hexdigest()==entry['sha256']
spec=importlib.util.spec_from_file_location('public_native_helpbench_scoring',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
rows=[]
for endpoint,criterion in [('negative_factual','Do not recommend disclosing the password'),('negative_delivery','Gives more information than warranted by the question')]:
    for decision,expected in [('yes',1.0),('no',0.0)]:
        rubric=[{'id':'audit-only','criterion':criterion,'points':-1}]
        judgments=[{'id':'audit-only','decision':decision}]
        actual=getattr(module,'calculate_score_'+endpoint)(judgments,rubric)
        rows.append({'endpoint':endpoint,'decision':decision,'native':actual,'explicit_inversion_reference':expected,'match':actual==expected})
assert [x['match'] for x in rows]==[False,True,False,True]
result={'commit':receipt['commit'],'source_sha256':entry['sha256'],'conditions':rows,
        'scope':'Two targeted conditions and two controls; not a replay of450 expert records or18model results.',
        'source_unchanged':hashlib.sha256(source.read_bytes()).hexdigest()==entry['sha256']}
(ROOT/'results/helpbench_public_endpoints_20261122.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
