# HelpBench public-source follow-up

This supplement replays only the four authored conditions on the unchanged public scorer at Google/helpseeking commit958f29df00cb0f661d65c3c87a0a18e2d0724788. It does not rerun450 expert examples, model ratings or the original study.

Install absl-py2.3.1 in a Python3.12 environment, then run `python check_helpbench_public_endpoints_20261122.py`. The script checks the scorer hash before execution and writes results/helpbench_public_endpoints_20261122.json. Compare its conditions to EXPECTED.json. Two zero-input helper outcomes returnNone; the two complementary controls return0.

The12-file comparison receipt records the separately performed remote acquisition. Only the scorer needed for this replay is included here; paths for other files in that receipt do not assert those files are packaged. The unchanged original study remains a separate reproduction directory.

Authored code: MIT, see LICENSE_CODE.txt. Authored report: CC BY4.0. Upstream scorer: Apache2.0, retained under data/helpbench/files/LICENSE.
