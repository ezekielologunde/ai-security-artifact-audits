Compile main.tex with the standard installed acmart class. Preliminary technical report, no ACM acceptance claimed.
