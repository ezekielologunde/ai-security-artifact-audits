Compile main.tex using the installed acmart class. Preliminary technical report; no ACM acceptance claimed.
