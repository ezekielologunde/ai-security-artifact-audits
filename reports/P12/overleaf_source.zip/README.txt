Compile main.tex with the standard installed acmart class. Technical research report; no ACM acceptance claimed.
